<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Goede Morgen</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php

$timezone = ("Europe/Amsterdam");
date_default_timezone_set($timezone);

$time = date('H:i');


if ($time < "06.00") {
    echo "<h1>Goede nacht</h1>";
    echo "<h2>Het is nu " . $time . "</h2>";
    echo "<body style='background-image: url(img/night.png);'>";
} else if ($time < "12.00") {
    echo "<h1>Goede morgen</h1>";
    echo "<h2>Het is nu " . $time . "</h2>";
    echo "<body style='background-image: url(img/morning.png);'>";
} else if ($time < "18.00") {
    echo "<h1>Goede middag</h1>";
    echo "<h2>Het is nu " . $time . "</h2>";
    echo "<body style='background-image: url(img/afternoon.png);'>";
} else if ($time < "23.59") {
    echo "<h1>Goede avond</h1>";
    echo "<h2>Het is nu " . $time . "</h2>";
    echo "<body style='background-image: url(img/evening.png);'>";
}

?>

</body>
</html>